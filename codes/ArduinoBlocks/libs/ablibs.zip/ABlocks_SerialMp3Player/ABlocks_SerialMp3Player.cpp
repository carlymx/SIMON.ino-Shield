#include <Arduino.h>
#include "ABlocks_SerialMp3Player.h"

ABlocks_SerialMp3Player::ABlocks_SerialMp3Player(Stream *_serial)
{
  m_serial=_serial;  
}

void ABlocks_SerialMp3Player::begin()
{
	delay(500);
	write_command(CMD_SEL_DEV, 0, DEV_TF);
  
	delay(500);
	setVolume(30);
};

 
void ABlocks_SerialMp3Player::setVolume(uint8_t volume)
	{
	write_command(CMD_SET_VOLUME, 0,volume);
	};

void ABlocks_SerialMp3Player::playIndex(uint16_t index)
	{
	write_command(CMD_PLAY_W_INDEX, (index>>8)&0xFF, index&0xFF);
	};

void ABlocks_SerialMp3Player::playFromFolder(uint8_t folder, uint8_t index)
	{
	write_command(CMD_PLAY_FOLDER_FILE, folder, index); 
	};	
	
void ABlocks_SerialMp3Player::write_command(uint8_t command, uint8_t data1, uint8_t data2)
	{  
	mp3Buffer[0] = 0x7E;    //
  mp3Buffer[1] = 0xFF;    //
  mp3Buffer[2] = 0x06;    // Len
  mp3Buffer[3] = command; //
  mp3Buffer[4] = 0x00;    // 0x00 NO, 0x01 feedback
  mp3Buffer[5] = data1;    // datah
  mp3Buffer[6] = data2;    // datal
  mp3Buffer[7] = 0xEF;    //
  
  for (uint8_t i = 0; i < 8; i++)
  {
    m_serial->write(mp3Buffer[i]) ;
  }
};

