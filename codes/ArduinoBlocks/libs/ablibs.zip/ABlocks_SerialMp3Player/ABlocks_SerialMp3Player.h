#ifndef __ABLOCKS_SERIALMP3PLAYER__
#define __ABLOCKS_SERIALMP3PLAYER__

#include <stdint.h>

#define	BYTE_START		0x7E
#define BYTE_STOP		  0xEF

#define CMD_NEXT_SONG     0X01  // Play next song.
#define CMD_PREV_SONG     0X02  // Play previous song.
#define CMD_PLAY_W_INDEX  0X03
#define CMD_VOLUME_UP     0X04
#define CMD_VOLUME_DOWN   0X05
#define CMD_SET_VOLUME    0X06

#define CMD_SNG_CYCL_PLAY 0X08  // Single Cycle Play.
#define CMD_SEL_DEV       0X09
#define CMD_SLEEP_MODE    0X0A
#define CMD_WAKE_UP       0X0B
#define CMD_RESET         0X0C
#define CMD_PLAY          0X0D
#define CMD_PAUSE         0X0E
#define CMD_PLAY_FOLDER_FILE 0X0F

#define CMD_STOP_PLAY     0X16  // Stop playing continuously. 
#define CMD_FOLDER_CYCLE  0X17
#define CMD_SHUFFLE_PLAY  0x18 //
#define CMD_SET_SNGL_CYCL 0X19 // Set single cycle.

#define CMD_SET_DAC 0X1A
#define DAC_ON  0X00
#define DAC_OFF 0X01

#define CMD_PLAY_W_VOL    0X22
#define CMD_PLAYING_N     0x4C
#define CMD_QUERY_STATUS      0x42
#define CMD_QUERY_VOLUME      0x43
#define CMD_QUERY_FLDR_TRACKS 0x4e
#define CMD_QUERY_TOT_TRACKS  0x48
#define CMD_QUERY_FLDR_COUNT  0x4f

/************ Opitons **************************/
#define DEV_TF 0X02


class ABlocks_SerialMp3Player
	{
	public:
		ABlocks_SerialMp3Player(Stream *_serial);
	
		void begin(void);
   
    void setVolume(uint8_t volume);
		void playIndex(uint16_t index);
		void playFromFolder(uint8_t folder, uint8_t index);
				
	private:
		void write_command(uint8_t command, uint8_t data1,uint8_t data2);
    Stream *m_serial;
    uint8_t mp3Buffer[8];
	};
	
#endif
